<?php
include("../class/danhmuc.class.php");

if (isset($_POST['ten'])){
	$dm = new DanhMuc();
	$dm->ten=$_POST['ten'];
	
	$dm->insert();
	header("location: danhmuc.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table border="0" align="center" cellspacing="0">
    <tr>
      <th scope="row">Tên danh mục</th>
      <td><label>
        <input name="ten" type="text" id="ten" size="50" />
      </label></td>
    </tr>

    <tr>
      <th scope="row">&nbsp;</th>
      <td><label>
        <input type="submit" name="button" id="button" value="Thêm mới" />
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>
