<?php
include("../class/sanpham.class.php");

$sp = new SanPham();
$sp->delete($_GET['id']);

header("location: sanpham.php");
?>