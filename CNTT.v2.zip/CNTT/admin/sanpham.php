<?php
include("../class/sanpham.class.php");

$sp = new SanPham();
$result = $sp->selectAll();

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="100%" border="1" cellspacing="0">
  <tr>
    <td>STT</td>
    <td>Danh mục</td>
    <td>Tên sản phẩm</td>
    <td>Số lượng</td>
    <td>Đơn giá</td>
    <td>Ảnh</td>
    <td>Mô tả</td>
    <td>Chức năng</td>
  </tr>
<?php
$stt=1;
foreach ($result as $row ) 
{
?>  
  <tr>
    <td><?php echo $stt++; ?></td>
    <td><?php echo $row['ten']; ?></td>
    <td><?php echo $row['tensanpham']; ?></td>
    <td><?php echo $row['soluong']; ?></td>
    <td><?php echo $row['dongia']; ?></td>
    <td><img src="../uploads/<?php echo $row['hinhanh']; ?>" width="60" height="60" /></td>
    <td><?php echo $row['mota']; ?></td>
    <td>
    <a href="sanpham_del.php?id=<?php echo $row['id']; ?>">Delete</a> | 
    <a href="sanpham_edit.php?id=<?php echo $row['id']; ?>">Edit</a>
    </td>
  </tr>
<?php
}
?>  
</table>

<p><a href="sanpham_insert.php">Insert</a></p>
</body>
</html>
