<?php
include("../class/acount.class.php");

$ac = new Acount();
$result = $ac->selectAll();

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table width="100%" border="1" cellspacing="0">
  <tr>
    <td>Họ tên</td>
    <td>Tên đăng nhập</td>
    <td>Giới tính</td>
    <td>Email</td>
    <td>Chức năng</td>
  </tr>
<?php
foreach ($result as $row ) 
{
?>  
  <tr>
    <td><?php echo $row['hoten']; ?></td>
    <td><?php echo $row['tendangnhap']; ?></td>
    <td><?php echo $row['gioitinh']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td>
    <a href="acount_del.php?id=<?php echo $row['tendangnhap']; ?>">Delete</a> | 
    <a href="acount_edit.php?id=<?php echo $row['tendangnhap']; ?>">Edit</a>
    </td>
  </tr>
<?php
}
?>  
</table>

<p><a href="acount_insert.php">Insert</a></p>
</body>
</html>
