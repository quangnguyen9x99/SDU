<?php
include("../class/danhmuc.class.php");

$dm = new DanhMuc();
$dm->delete($_GET['id']);

header("location: danhmuc.php");
?>