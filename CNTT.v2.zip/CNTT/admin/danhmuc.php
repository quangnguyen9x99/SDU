<?php
include("../class/danhmuc.class.php");

$dm = new DanhMuc();
$result = $dm->selectAll();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="1" cellspacing="0">
  <tr>
    <td>STT</td>
    <td>Tên danh mục</td>
    <td>Chức năng</td>
  </tr>
<?php
$stt=0;
foreach ($result as $row ) 
{
?>  
  <tr>
    <td><?php echo $stt++; ?></td>
    <td><?php echo $row['ten']; ?></td>
    <td>
    <a href="danhmuc_del.php?id=<?php echo $row['id']; ?>">Delete</a> | 
    <a href="danhmuc_edit.php?id=<?php echo $row['id']; ?>">Edit</a>
    </td>
  </tr>
<?php
}
?>  
</table>

<p><a href="danhmuc_insert.php">Insert</a></p>




</body>
</html>
