<?php
include("../class/danhmuc.class.php");
$dm = new DanhMuc();
//Lấy thông tin sp cần sửa
if (isset($_GET['id'])){	
	$result = $dm->selectById($_GET['id']);
}


//Thực hiện sửa
if (isset($_POST['btSubmit'])){
	$dm->id=$_POST['id'];//Nhận giá trị từ trường ẩn input type="hidden"...
	$dm->ten=$_POST['ten'];
	
	$dm->update();
	header("location: danhmuc.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table border="0" align="center" cellspacing="0">
    <tr>
      <th scope="row">Tên danh mục</th>
      <td><label>
        <input name="ten" type="text" id="ten" size="50" value="<?php echo $result['ten']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td><label>
        <input type="submit" name="btSubmit" id="btSubmit" value="Sửa" />
        <input type="hidden" name="id" id="id" value="<?php echo $result['id']; ?>" />
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>
