<?php
include("../class/acount.class.php");

$ac = new Acount();
$ac->delete($_GET['id']);

header("location: acount.php");
?>