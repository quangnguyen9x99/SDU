<?php
include("../class/acount.class.php");

if (isset($_POST['btSubmit'])){
	$ac = new Acount();
	$ac->tendangnhap=$_POST['tendangnhap'];
	$ac->matkhau=$_POST['matkhau'];
	$ac->hoten=$_POST['hoten'];
	$ac->gioitinh=$_POST['gioitinh'];
	$ac->email=$_POST['email'];
	
	$ac->insert();
	header("location: acount.php");
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="400" border="0" cellspacing="0">
    <tr>
      <th scope="row"><div align="right">Tên đăng nhập</div></th>
      <td><label>
        <input type="text" name="tendangnhap" id="tendangnhap" />
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Mật khẩu</div></th>
      <td><label>
        <input type="text" name="matkhau" id="matkhau" />
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Họ tên</div></th>
      <td><label>
        <input type="text" name="hoten" id="hoten" />
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Giới tính</div></th>
      <td><label>
        <select name="gioitinh" id="gioitinh">
          <option value="1">Nam</option>
          <option value="0">Nữ</option>
                </select>
      </label></td>
    </tr>
    <tr>
      <th scope="row"><div align="right">Email</div></th>
      <td><label>
        <input type="text" name="email" id="email" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td><input type="submit" name="btSubmit" id="btSubmit" value="Thêm mới" /></td>
    </tr>
  </table>
</form>
</body>
</html>
