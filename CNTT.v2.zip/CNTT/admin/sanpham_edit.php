<?php
include("../class/danhmuc.class.php");
include("../class/sanpham.class.php");
//Lấy các danh mục, hiển thị vào list,menu
$dm = new DanhMuc();
$result_dm = $dm->selectAll();

//Lấy thông tin sản phẩm cần sửa
$sp = new SanPham();
if (isset($_GET['id'])){	
	$result_sp = $sp->selectById($_GET['id']);
}

//Thực hiện sửa sản phẩm
if (isset($_POST['btSubmit'])){
	$sp = new SanPham();
	$sp->id=$_POST['id'];
	$sp->iddanhmuc=$_POST['iddanhmuc'];
	$sp->tensanpham=$_POST['tensanpham'];
	$sp->soluong=$_POST['soluong'];
	$sp->dongia=$_POST['dongia'];
	$sp->hinhanh=$_POST['hinhanh'];
	$sp->mota=$_POST['mota'];
	
	$sp->update();
	header("location: sanpham.php");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table border="0" cellspacing="0">
    <tr>
      <th scope="row">Danh mục sản phẩm</th>
      <td><label>
        <select name="iddanhmuc" id="iddanhmuc">
          <?php
foreach ($result_dm as $muc ) 
{
?>
          <option value="<?php echo $muc['id']; ?>"
           <?php if ($muc['id']==$result_sp['iddanhmuc']) echo "selected"; ?>
            >
		   <?php echo $muc['ten']; ?>
           </option>
          <?php
}
?>
        </select>
      </label></td>
    </tr>
    <tr>
      <th scope="row">Tên sản phẩm</th>
      <td><label>
        <input name="tensanpham" type="text" id="tensanpham" size="50" value="<?php echo $result_sp['tensanpham']; ?>" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Số lượng</th>
      <td><label>
        <input type="text" name="soluong" id="soluong" value="<?php echo $result_sp['soluong']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <th scope="row">Đơn giá</th>
      <td><label>
        <input type="text" name="dongia" id="dongia" value="<?php echo $result_sp['dongia']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <th scope="row">Hình ảnh</th>
      <td><label>
        <input name="hinhanh" type="text" id="hinhanh" size="50" value="<?php echo $result_sp['hinhanh']; ?>"/>
      </label></td>
    </tr>
    <tr>
      <th scope="row">Mô tả</th>
      <td><label>
        <textarea name="mota" cols="50" rows="10" id="mota"><?php echo $result_sp['mota']; ?></textarea>
      </label></td>
    </tr>
    <tr>
      <th scope="row">&nbsp;</th>
      <td><label>
        <input type="submit" name="btSubmit" id="btSubmit" value="Sửa" />
        <input type="hidden" name="id" id="id" value="<?php echo $result_sp['id']; ?>" />
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>
