<?php
//Lấy các danh mục, hiển thị vào list,menu
include("../class/danhmuc.class.php");
$dm = new DanhMuc();
$result_dm = $dm->selectAll();
//Thực hiện thêm mới sản phẩm
include("../class/sanpham.class.php");
$newfilename = "";
//Nếu submit form
if (isset($_POST['btSubmit'])){
	//Nếu có file hình ảnh
	if (isset($_FILES["hinhanh"])){
		$uploaddir = '../uploads/';
		$newfilename = "".time()."_". str_replace(' ','_',$_FILES['hinhanh']['name'])."";
		$path = $uploaddir.$newfilename;
		//Upload
		if(!move_uploaded_file($_FILES["hinhanh"]['tmp_name'],$path)) 
		{
			echo "<SCRIPT language='Javascript'> alert('Lỗi upload!'); </SCRIPT>";
		}
	}
	//thêm mới
	$sp = new SanPham();
	$sp->iddanhmuc=$_POST['iddanhmuc'];
	$sp->tensanpham=$_POST['tensanpham'];
	$sp->soluong=$_POST['soluong'];
	$sp->dongia=$_POST['dongia'];
	$sp->hinhanh=$newfilename;
	$sp->mota=$_POST['mota'];
	
	$sp->insert();
	header("location: sanpham.php");
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <table border="0" cellspacing="0">
    <tr>
      <th scope="row">Danh mục sản phẩm</th>
      <td><label>
        <select name="iddanhmuc" id="iddanhmuc">
          
        <?php
foreach ($result_dm as $muc ) 
{
?>
<option value="<?php echo $muc['id']; ?>"><?php echo $muc['ten']; ?></option>

<?php
}
?>
        </select>
      </label></td>
    </tr>
    <tr>
      <th scope="row">Tên sản phẩm</th>
      <td><label>
        <input name="tensanpham" type="text" id="tensanpham" size="50" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Số lượng</th>
      <td><label>
        <input type="text" name="soluong" id="soluong" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Đơn giá</th>
      <td><label>
        <input type="text" name="dongia" id="dongia" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Hình ảnh</th>
      <td><label>
      <input type="file" name="hinhanh" id="hinhanh" />
      </label></td>
    </tr>
    <tr>
      <th scope="row">Mô tả</th>
      <td><label>
        <textarea name="mota" cols="50" rows="10" id="mota"></textarea>
      </label></td>
    </tr>

    <tr>
      <th scope="row">&nbsp;</th>
      <td><label>
        <input type="submit" name="btSubmit" id="btSubmit" value="Thêm mới" />
      </label></td>
    </tr>
  </table>
</form>
</body>
</html>
