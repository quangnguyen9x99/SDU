<?php
include_once "database.class.php";
class SanPham extends Database
{
	public $id;
	public $iddanhmuc;
	public $tensanpham;
	public $soluong;
	public $dongia;
	public $hinhanh;
	public $mota;
	
	function selectAll()
	{
		$sql = "SELECT tbsanpham.*, tbdanhmuc.ten FROM tbsanpham, tbdanhmuc where tbsanpham.iddanhmuc = tbdanhmuc.id";
		$result = $this->query($sql);
		return $result;
	}
	
	function selectById($id)
	{
		$sql = "SELECT * FROM tbsanpham where id = '".$id."'";
		//die($sql);
		$result = $this->queryArray($sql);
		return $result;
	}
		
	function delete($id){
		$this->id=$id;
		$sql = "Delete from tbsanpham where id='".$this->id."'";		
		$result = $this->non_query($sql);
	}
		
	function update(){
		$sql = "Update tbsanpham set iddanhmuc='".$this->iddanhmuc."',tensanpham='".$this->tensanpham."',soluong='".$this->soluong."',dongia='".$this->dongia."',hinhanh='".$this->hinhanh."',mota='".$this->mota."' where id='".$this->id."'";		
		//die($sql);
		$result = $this->non_query($sql);
	}

	function insert(){		
		$sql = "Insert into tbsanpham(iddanhmuc,tensanpham,soluong,dongia,hinhanh,mota)  values('".$this->iddanhmuc."','".$this->tensanpham."','".$this->soluong."','".$this->dongia."','".$this->hinhanh."','".$this->mota."')";		
		//die($sql);
		$result = $this->non_query($sql);
	}
}
?>
