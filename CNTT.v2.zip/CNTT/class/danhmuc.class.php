<?php
include_once "database.class.php";
class DanhMuc extends Database
{
	public $id;
	public $ten;
	
	function selectAll()
	{
		$sql = "SELECT * FROM tbdanhmuc";
		$result = $this->query($sql);
		return $result;
	}
	
	function selectById($id)
	{
		$sql = "SELECT * FROM tbdanhmuc where id = '".$id."'";
		//die($sql);
		$result = $this->queryArray($sql);
		return $result;
	}
		
	function delete($id){
		$this->id=$id;
		$sql = "Delete from tbdanhmuc where id='".$this->id."'";		
		$result = $this->non_query($sql);
		//X�a c�c s?m ph?m c?a danh m?c c?n x�a
		$sql = "Delete from tbsanpham where iddanhmuc='".$this->id."'";		
		$result = $this->non_query($sql);
	}
		
	function update(){
		$sql = "Update tbdanhmuc set ten='".$this->ten."' where id='".$this->id."'";		
		//die($sql);
		$result = $this->non_query($sql);
	}	
	function insert(){		
		$sql = "Insert into tbdanhmuc(ten)  values('".$this->ten."')";		
		//die($sql);
		$result = $this->non_query($sql);
	}
}
?>