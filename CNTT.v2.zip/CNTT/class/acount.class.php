<?php
include_once "database.class.php";
class Acount extends Database
{
	public $tendangnhap;
	public $matkhau;
	public $hoten;
	public $gioitinh;
	public $email;
	
	function selectAll()
	{
		$sql = "SELECT * FROM tbacount";
		$result = $this->query($sql);
		return $result;
	}
	
	function selectById($id)
	{
		$sql = "SELECT * FROM tbacount where tendangnhap = '".$id."'";
		//die($sql);
		$result = $this->queryArray($sql);
		return $result;
	}
		
	function delete($id){
		$this->tendangnhap=$id;
		$sql = "Delete from tbacount where tendangnhap='".$this->tendangnhap."'";		
		$result = $this->non_query($sql);
	}
		
	function update(){
		$sql = "Update tbacount set matkhau='".$this->matkhau."',hoten='".$this->hoten."',gioitinh='".$this->gioitinh."',email='".$this->email."' where tendangnhap='".$this->tendangnhap."'";		
		//die($sql);
		$result = $this->non_query($sql);
	}	
	function insert(){		
		$sql = "Insert into tbacount(tendangnhap,matkhau,hoten,gioitinh,email)  values('".$this->tendangnhap."','".$this->matkhau."','".$this->hoten."','".$this->gioitinh."','".$this->email."')";		
		//die($sql);
		$result = $this->non_query($sql);
	}
}
?>
