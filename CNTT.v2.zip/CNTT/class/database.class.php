<?php
class Database
{
	private $server="localhost";
	private $username="root";
	private $password="";
	private $dbname="cntt7";
	private $conn;
	private $result;
		
	function database()
	{
		$this->connect();
	}
	
	function connect(){
		$this->conn = mysql_connect($this->server, $this->username, $this->password);
		if ( !$this->conn ) {
			return false;
		} else {	
			mysql_select_db($this->dbname, $this->conn);
			return $this->conn;
		}
	}
	//D�ng nh?n l?i k?t qu? truy v?n l� nhi?u d�ng
	function query($sql){
		$this->result = mysql_query($sql, $this->conn);
		$arr = array();
		while ($row = mysql_fetch_assoc($this->result)) 		{
			$arr[] = $row;
		}
		return $arr;
	}
	//D�ng nh?n l?i k?t qu? truy v?n l� 1 d�ng
	function queryArray($sql){
		$this->result = mysql_query($sql, $this->conn);		
		return mysql_fetch_array($this->result);
	}
	
	function non_query($sql){
		$this->result = mysql_query($sql, $this->conn);
	}
	
	function free_result(){
		mysql_free_result($this->result);
	}
	
	function close(){
		mysql_close($this->conn);
	}

}
?>
